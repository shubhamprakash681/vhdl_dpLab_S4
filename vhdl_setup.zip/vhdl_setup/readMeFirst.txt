   For offline setup:
   Download a text editor (vs code)
   Download ghdl & gtkwave (provided in this folder)
   install text editor
   install vscode vhdl extension:- vhdlbyvhdlwhiz (ss shared in this folder)
   unzip ghdl & gtkwave & copy it to say(C:\Program Files\gtkwave)  (C:\Program Files\0.37-mingw64-llvm)
   add system environment path for both of them:- 
     for gdhdl:- C:\Program Files\0.37-mingw64-llvm\bin
     for gtkwave:- C:\Program Files\gtkwave\bin
   Offline setup complete....
   
   
   
   For online: use edaplayground.com




    ****  ghdl cmnds for offline setup
ghdl -s fileName.vhdl  -->check for syntax error
ghdl -a fileName.vhdl  -->analyse (compile)
ghdl -e testBenchName  -->elaborate the testBench
ghdl -r testBenchName  -->run (execute in terminal)
ghdl -r testBenchName --vcd=vcdNewFileName.vcd  -->generate file for waveform viewer (gtkwave in our case)..
gtkwave vcdFileName.vcd  --finally execute vcd file into gtkwave



Example:-
ghdl -s ha.vhdl  (can skip if don't want to check syntax)
ghdl -s ha_tb.vhdl  (can skip if don't want to check syntax)
ghdl -a ha.vhdl
ghdl -a ha_tb.vhdl
ghdl -e ha_tb
ghdl -r ha_tb  (can skip this if not willing to run in terminal)
ghdl -r ha_tb --vcd=halfAdder.vcd



